<?php
// الاتصال بقاعدة البيانات
$host = "localhost";
$db = "offers_db";
$user = "root";
$pass = ""; // أو كلمة المرور حقك

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

// استلام البيانات من العرض
$user_id = $_GET['user_id'] ?? null;
$points = $_GET['points'] ?? 0;

// تحقق
if ($user_id && $points > 0) {
    $stmt = $conn->prepare("UPDATE users SET points = points + ? WHERE id = ?");
    $stmt->bind_param("ii", $points, $user_id);
    $stmt->execute();

    echo "تمت إضافة $points نقطة للمستخدم ID: $user_id";
} else {
    echo "بيانات غير صالحة.";
}

$conn->close();
?>