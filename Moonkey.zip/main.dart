import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MaterialApp(
    home: OffersPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class OffersPage extends StatelessWidget {
  final List<Map<String, String>> offers = [
    {
      'title': 'تجربة لعبة جديدة',
      'description': 'العب حتى المستوى 500 واربح 1000 نقطة.',
      'button': 'جرب اللعبة',
      'url': 'https://play.google.com/store/apps/details?id=com.example.game1',
    },
    {
      'title': 'استبيان سريع',
      'description': 'أجب على بعض الأسئلة واحصل على 90 نقطة.',
      'button': 'ابدأ الاستبيان',
      'url': 'https://example.com/survey',
    },
    {
      'title': 'اشترك في النشرة البريدية',
      'description': 'احصل على 80 نقطة عند الاشتراك.',
      'button': 'اشترك الآن',
      'url': 'https://example.com/newsletter',
    },
    {
      'title': 'تطبيق الصحة',
      'description': 'نزل تطبيق الصحة وأكمل تسجيلك لتحصل على 60 نقطة.',
      'button': 'نزل التطبيق',
      'url': 'https://play.google.com/store/apps/details?id=com.example.health',
    },
    {
      'title': 'حمل تطبيق VPN',
      'description': 'احصل على 100 نقطة عند تثبيت التطبيق.',
      'button': 'ابدأ الآن',
      'url': 'https://play.google.com/store/apps/details?id=com.example.vpn',
    },
    {
      'title': 'شاهد فيديو إعلاني',
      'description': 'اكسب 50 نقطة بمشاهدة فيديو مدته 50 ثانية.',
      'button': 'شاهد الآن',
      'url': 'https://example.com/video',
    },
    {
      'title': 'سجل في موقع تسوق',
      'description': 'سجل باستخدام بريدك الإلكتروني لتحصل على 300 نقطة.',
      'button': 'سجل الآن',
      'url': 'https://example.com/shop',
    },
  ];

  void _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw 'لا يمكن فتح الرابط: $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('عروض MoonKeyCash'),
        backgroundColor: Colors.orange,
      ),
      body: ListView.builder(
        itemCount: offers.length,
        itemBuilder: (context, index) {
          final offer = offers[index];
          return Card(
            margin: EdgeInsets.all(12),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    offer['title']!,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.deepOrange),
                  ),
                  SizedBox(height: 10),
                  Text(
                    offer['description']!,
                    textAlign: TextAlign.right,
                    style: TextStyle(fontSize: 14),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: () => _launchURL(offer['url']!),
                    child: Text(offer['button']!),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}