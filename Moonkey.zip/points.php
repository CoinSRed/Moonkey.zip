<?php
$host = "localhost";
$db = "offers_db";
$user = "root";
$pass = "";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

$user_id = $_GET['user_id'] ?? null;

if ($user_id) {
    $result = $conn->query("SELECT username, points FROM users WHERE id = $user_id");
    if ($row = $result->fetch_assoc()) {
        echo "المستخدم: " . $row['username'] . "<br>";
        echo "النقاط: " . $row['points'];
    } else {
        echo "المستخدم غير موجود.";
    }
} else {
    echo "لم يتم تحديد ID.";
}

$conn->close();
?>